#List of words with little to no semantic value
#May require changing if the binary is changed

stop_words = [
    "the", "and", "a", "an", "at", "in", "on", "for", "to", "from", "of",
    "is", "am", "are", "was", "were", "be", "been", "being",
    "it", "its", "this", "that", "those", "these",
    "he", "she", "they", "them", "his", "her", "their",
    "you", "your", "yours", "we", "our", "ours", "i", "me", "my", "mine",
    "but", "or", "so", "nor", "yet",
    "as", "by", "with", "without", "about", "into", "through", "over",
    "under", "again", "further", "then", "once",
    "just", "also", "too", "very",
    "can", "could", "should", "would", "may", "might", "must",
    "do", "does", "did", "doing",
    "have", "has", "had", "having",
    "will", "shall",
    "not", "no", "yes",
    "up", "down", "out", "off", "only", "both", "all", "any", "each",
    "such", "other", "some", "more", "most", "many",
    "there", "here", "when", "where", "why", "how",
    "because", "while", "if", "until", "than",
    "what", "which", "who", "whom", "whose",
    "before", "after", "during",
    "same", "few", "several",
    "ever", "always", "sometimes",
    "above", "below",
    "over", "under",
    "between", "among",
    "per"
]
