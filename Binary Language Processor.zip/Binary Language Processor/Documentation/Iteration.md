v0.01:
	Pushed initial software topology
	Testing utility functions required
	